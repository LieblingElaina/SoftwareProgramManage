const envList = [{"envId":"lesql-3gylsjx5011b6612","alias":"lesql"}]
const isMac = false
module.exports = {
    envList,
    isMac
}